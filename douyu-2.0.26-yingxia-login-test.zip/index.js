const _douyu_playbackUserAgent = "libmpv";

function _lp_decodePercent(s) {
  try {
    return decodeURIComponent(s);
  } catch (e) {
    return s;
  }
}

function _douyu_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  if (globalThis.Host && typeof Host.makeError === "function") {
    throw Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  throw new Error(`LP_PLUGIN_ERROR:${JSON.stringify({ code: String(code || "UNKNOWN"), message: String(message || ""), context: context || {} })}`);
}

function _lp_parseQuery(qs) {
  const out = {};
  if (!qs) return out;
  const parts = String(qs).split("&");
  for (const p of parts) {
    if (!p) continue;
    const idx = p.indexOf("=");
    const k = idx >= 0 ? p.slice(0, idx) : p;
    const v = idx >= 0 ? p.slice(idx + 1) : "";
    out[k] = _lp_decodePercent(v);
  }
  return out;
}

function _lp_isNumericId(roomId) {
  const s = String(roomId || "").trim();
  if (!/^\d+$/.test(s)) return false;
  const n = parseInt(s, 10);
  return Number.isFinite(n) && n > 0;
}

function _lp_firstMatch(text, re) {
  const m = String(text || "").match(re);
  if (!m || !m[1]) return "";
  return String(m[1]);
}

function _lp_firstURL(text) {
  const m = String(text || "").match(/https?:\/\/[^\s|]+/);
  if (!m) return "";
  return String(m[0]).replace(/[),，。】]+$/g, "");
}

function _douyu_extractRoomIdFromPage(html) {
  const text = String(html || "");
  const patterns = [
    /\\?"room_id\\?":\s*"?(\d+)/,
    /\\?"roomId\\?":\s*"?(\d+)/,
    /roomId\s*[:=]\s*"?(\d+)/
  ];
  for (const pattern of patterns) {
    const roomId = _lp_firstMatch(text, pattern);
    if (_lp_isNumericId(roomId)) return roomId;
  }
  return "";
}

function _lp_randomString(length) {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let out = "";
  for (let i = 0; i < length; i += 1) {
    out += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return out;
}

async function _douyu_getCategories() {
  const resp = await Host.http.request({
    url: "https://m.douyu.com/api/cate/list",
    method: "GET",
    timeout: 20
  });
  const obj = JSON.parse(resp.bodyText || "{}");
  if ((obj && obj.code) !== 0) {
    _douyu_throw("UPSTREAM", `category code invalid: ${obj && obj.code}`, { code: String((obj && obj.code) || "") });
  }

  const cate1Info = (obj && obj.data && obj.data.cate1Info) || [];
  const cate2Info = (obj && obj.data && obj.data.cate2Info) || [];

  return cate1Info.map(function (cate1) {
    const subList = cate2Info
      .filter(function (cate2) { return String(cate2.cate1Id || "") === String(cate1.cate1Id || ""); })
      .map(function (cate2) {
        return {
          id: String(cate2.cate2Id || ""),
          parentId: String(cate2.cate1Id || ""),
          title: String(cate2.cate2Name || ""),
          icon: String(cate2.icon || ""),
          biz: ""
        };
      });

    return {
      id: String(cate1.cate1Id || ""),
      title: String(cate1.cate1Name || ""),
      icon: "",
      biz: "",
      subList
    };
  });
}

function _douyu_mixListKey(id) {
  const cateId = String(id || "").trim();
  if (!cateId || cateId === "0") return "0_0";
  return `2_${encodeURIComponent(cateId)}`;
}

async function _douyu_getRooms(id, page) {
  const url = `https://www.douyu.com/gapi/rkc/directory/mixList/${_douyu_mixListKey(id)}/${encodeURIComponent(String(page))}`;
  const resp = await Host.http.request({
    url,
    method: "GET",
    timeout: 20
  });
  const obj = JSON.parse(resp.bodyText || "{}");
  if ((obj && obj.code) !== 0) {
    _douyu_throw("UPSTREAM", `room list code invalid: ${obj && obj.code}`, { code: String((obj && obj.code) || "") });
  }

  const list = (obj && obj.data && obj.data.rl) || [];
  return list
    .filter(function (item) { return Number(item.type || 0) === 1; })
    .map(function (item) {
      const av = String(item.av || "");
      const avMiddle = av ? `https://apic.douyucdn.cn/upload/${av}_middle.jpg` : "";
      return {
        userName: String(item.nn || ""),
        roomTitle: String(item.rn || ""),
        roomCover: _douyu_hdImageURL(String(item.rs16_avif || "") || avMiddle),
        userHeadImg: avMiddle,
        liveType: "3",
        liveState: "",
        userId: String(item.uid || "0"),
        roomId: String(item.rid || "0"),
        liveWatchedCount: String(item.ol || "0")
      };
    });
}

const __douyu_homeSectionRoomLimit = 20;
const __douyu_homeTTLSeconds = 900;

function _douyu_httpsURL(url) {
  const value = String(url || "").trim();
  if (!value) return "";
  if (value.indexOf("//") === 0) return "https:" + value;
  if (value.indexOf("http://") === 0) return "https://" + value.slice(7);
  return value;
}

function _douyu_hdImageURL(url) {
  const value = _douyu_httpsURL(url);
  if (!value) return "";
  return value.replace(/\/dy1(?=[/?#]|$)/i, "/dy4");
}

function _douyu_mapHomeRoom(item) {
  const roomId = String((item && item.roomId) || "").trim();
  if (!roomId || roomId === "0") return null;
  const liveState = String((item && item.liveState) || "").trim();
  return {
    userName: String((item && item.userName) || ""),
    roomTitle: String((item && item.roomTitle) || ""),
    roomCover: _douyu_httpsURL((item && item.roomCover) || ""),
    userHeadImg: _douyu_httpsURL((item && item.userHeadImg) || ""),
    liveType: "3",
    liveState: liveState || "1",
    userId: String((item && item.userId) || ""),
    roomId: roomId,
    liveWatchedCount: String((item && item.liveWatchedCount) || "")
  };
}

async function _douyu_getHomeRoomList(id) {
  const rows = await _douyu_getRooms(id, 1);
  const out = [];
  for (let i = 0; i < rows.length; i += 1) {
    const room = _douyu_mapHomeRoom(rows[i]);
    if (room) out.push(room);
  }
  return out;
}

function _douyu_homeBannerFromRoom(room, imageURL, badge) {
  if (!room || !room.roomId) return null;
  const bannerImage = _douyu_httpsURL(imageURL || room.roomCover);
  if (bannerImage.indexOf("https://") !== 0) return null;
  const title = String(room.roomTitle || room.userName || "").trim();
  if (!title) return null;
  const banner = {
    id: "banner-" + room.roomId,
    imageURL: bannerImage,
    title: title,
    badge: String(badge || "直播中").trim() || "直播中",
    target: {
      type: "room",
      room: room
    }
  };
  const subtitle = String(room.userName || "").trim();
  if (subtitle && subtitle !== title) banner.subtitle = subtitle;
  return banner;
}

function _douyu_isAvifURL(url) {
  return /\.avif(?:$|[?#/])/i.test(String(url || ""));
}

function _douyu_pickBannerImage(urls) {
  const source = urls || [];
  const normalized = [];
  for (let i = 0; i < source.length; i += 1) {
    const url = _douyu_hdImageURL(source[i]);
    if (!url || url.indexOf("https://") !== 0) continue;
    normalized.push(url);
  }
  for (let i = 0; i < normalized.length; i += 1) {
    if (!_douyu_isAvifURL(normalized[i])) return normalized[i];
  }
  return normalized.length ? normalized[0] : "";
}

function _douyu_normalizeSwitcherImage(url) {
  let value = _douyu_httpsURL(url);
  if (!value) return "";
  const isAvif = _douyu_isAvifURL(value);
  value = value.replace(/\/b(?:jpg|webp|png)(?=[/?#]|$)/i, "");
  value = _douyu_hdImageURL(value);
  if (isAvif && value && !/\/bjpg(?=[/?#]|$)/i.test(value)) {
    const hash = value.indexOf("#");
    const query = value.indexOf("?");
    const cut = query >= 0 && (hash < 0 || query < hash) ? query : hash;
    if (cut >= 0) value = value.slice(0, cut) + "/bjpg" + value.slice(cut);
    else value += "/bjpg";
  }
  return value;
}

function _douyu_unescapeNextF(text) {
  let decoded = String(text || "");
  for (let i = 0; i < 3; i += 1) {
    if (decoded.indexOf("\\\"") < 0 && decoded.indexOf("\\\\") < 0) break;
    decoded = decoded.replace(/\\"/g, "\"").replace(/\\n/g, "\n").replace(/\\\\/g, "\\");
  }
  return decoded;
}

function _douyu_sliceJsonValue(text, start) {
  const source = String(text || "");
  if (start < 0 || start >= source.length) return "";
  const open = source.charAt(start);
  const close = open === "[" ? "]" : (open === "{" ? "}" : "");
  if (!close) return "";
  let depth = 0;
  let inStr = false;
  let escaped = false;
  for (let i = start; i < source.length; i += 1) {
    const ch = source.charAt(i);
    if (inStr) {
      if (escaped) {
        escaped = false;
        continue;
      }
      if (ch === "\\") {
        escaped = true;
        continue;
      }
      if (ch === "\"") inStr = false;
      continue;
    }
    if (ch === "\"") {
      inStr = true;
      continue;
    }
    if (ch === open) depth += 1;
    else if (ch === close) {
      depth -= 1;
      if (depth === 0) return source.slice(start, i + 1);
    }
  }
  return "";
}

function _douyu_parseItemsNearMarker(text, marker, itemsKey) {
  const source = String(text || "");
  const markerIdx = source.indexOf(marker);
  if (markerIdx < 0) return null;
  const keyIdx = source.lastIndexOf(itemsKey, markerIdx);
  if (keyIdx < 0) return null;
  const raw = _douyu_sliceJsonValue(source, keyIdx + itemsKey.length - 1);
  if (!raw) return null;
  try {
    const items = JSON.parse(raw);
    return Array.isArray(items) ? items : null;
  } catch (e) {
    return null;
  }
}

function _douyu_extractHomeSlideItems(html) {
  const source = String(html || "");
  if (!source) return [];

  const plain = _douyu_parseItemsNearMarker(source, "\"_rpos\":\"1079\"", "\"items\":[");
  if (plain) return plain;

  const escapedMarker = "\\\"_rpos\\\":\\\"1079\\\"";
  const escapedKey = "\\\"items\\\":[";
  const markerIdx = source.indexOf(escapedMarker);
  if (markerIdx >= 0) {
    const keyIdx = source.lastIndexOf(escapedKey, markerIdx);
    if (keyIdx >= 0) {
      const rawEscaped = _douyu_sliceJsonValue(source, keyIdx + escapedKey.length - 1);
      if (rawEscaped) {
        try {
          const parsed = JSON.parse(_douyu_unescapeNextF(rawEscaped));
          if (Array.isArray(parsed)) return parsed;
        } catch (e) {}
      }
    }
  }

  const decoded = _douyu_parseItemsNearMarker(
    _douyu_unescapeNextF(source),
    "\"_rpos\":\"1079\"",
    "\"items\":["
  );
  return decoded || [];
}

function _douyu_sliceSwitcherHtml(html) {
  const source = String(html || "");
  const markers = ["player-aside__", "switcherTabs__"];
  for (let i = 0; i < markers.length; i += 1) {
    const idx = source.indexOf(markers[i]);
    if (idx < 0) continue;
    const start = source.lastIndexOf("<", idx);
    if (start < 0) continue;
    return source.slice(start, Math.min(source.length, start + 40000));
  }
  return source;
}

function _douyu_extractSwitcherItems(html) {
  const source = _douyu_sliceSwitcherHtml(html);
  const items = [];
  const seen = {};
  const re = /<a\b[^>]*href=["'][^"'<>]*special\/jump\/(\d+)[^"']*["'][^>]*>([\s\S]*?)<\/a>/gi;
  let match = re.exec(source);
  while (match) {
    const roomId = String(match[1] || "").trim();
    if (_lp_isNumericId(roomId) && !seen[roomId]) {
      const block = match[2] || "";
      const img = _lp_firstMatch(block, /<img\b[^>]*\bsrc=["']([^"']+)["']/i)
        || _lp_firstMatch(block, /\bsrc=["']([^"']+)["']/i);
      const alt = _lp_firstMatch(block, /\balt=["']([^"']*)["']/i);
      seen[roomId] = true;
      items.push({
        rid: roomId,
        title: alt,
        picUrl: img
      });
    }
    match = re.exec(source);
  }
  return items;
}

function _douyu_indexSlideMeta(items) {
  const out = {};
  const source = items || [];
  for (let i = 0; i < source.length; i += 1) {
    const rid = String((source[i] && (source[i].rid || source[i].roomId)) || "").trim();
    if (_lp_isNumericId(rid)) out[rid] = source[i];
  }
  return out;
}

function _douyu_mergeSwitcherItems(html) {
  const switcher = _douyu_extractSwitcherItems(html);
  const ssr = _douyu_extractHomeSlideItems(html);
  if (!switcher.length) return ssr;
  const meta = _douyu_indexSlideMeta(ssr);
  const merged = [];
  for (let i = 0; i < switcher.length; i += 1) {
    const item = switcher[i];
    const info = meta[item.rid] || {};
    merged.push({
      rid: item.rid,
      title: item.title || info.title || "",
      cate2Name: info.cate2Name || "",
      status: info.status,
      fromSwitcher: true,
      pic: { picUrl: item.picUrl || (info.pic && info.pic.picUrl) || "" },
      picSlider: info.picSlider || null
    });
  }
  return merged;
}

function _douyu_mapHomeSlideItem(item) {
  const roomId = String((item && (item.rid || item.roomId)) || "").trim();
  if (!_lp_isNumericId(roomId)) return null;
  const cateName = String((item && item.cate2Name) || "").trim();
  const title = String((item && item.title) || "").trim() || cateName || ("房间" + roomId);
  const slider = item && item.picSlider && item.picSlider.picUrl;
  const pic = item && item.pic && item.pic.picUrl;
  const imageURL = item && item.fromSwitcher
    ? (_douyu_normalizeSwitcherImage(pic) || _douyu_pickBannerImage([slider]))
    : _douyu_pickBannerImage([slider, pic]);
  const room = {
    userName: "",
    roomTitle: title,
    roomCover: imageURL,
    userHeadImg: "",
    liveType: "3",
    liveState: String((item && item.status) == null ? "1" : item.status) === "0" ? "0" : "1",
    userId: "",
    roomId: roomId,
    liveWatchedCount: ""
  };
  return _douyu_homeBannerFromRoom(room, imageURL, cateName);
}

async function _douyu_getHomeSlideItems() {
  try {
    const resp = await Host.http.request({
      url: "https://www.douyu.com/",
      method: "GET",
      headers: {
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        referer: "https://www.douyu.com/",
        accept: "text/html,application/xhtml+xml"
      },
      timeout: 20
    });
    return _douyu_mergeSwitcherItems((resp && resp.bodyText) || "");
  } catch (e) {
    return [];
  }
}

function _douyu_collectHomeSlideBanners(items) {
  const banners = [];
  const seen = {};
  const source = items || [];
  for (let i = 0; i < source.length; i += 1) {
    const banner = _douyu_mapHomeSlideItem(source[i]);
    if (!banner || seen[banner.id]) continue;
    seen[banner.id] = true;
    banners.push(banner);
  }
  return banners;
}

function _douyu_homeSection(spec, rooms) {
  const items = [];
  const seen = {};
  const source = rooms || [];
  for (let i = 0; i < source.length && items.length < __douyu_homeSectionRoomLimit; i += 1) {
    const room = source[i];
    if (!room || !room.roomId || seen[room.roomId]) continue;
    seen[room.roomId] = true;
    items.push({
      id: room.roomId,
      room: room
    });
  }
  if (!items.length) return null;
  const section = {
    id: spec.id,
    kind: "rooms",
    title: spec.title,
    personalized: false,
    items: items
  };
  if (spec.subtitle) section.subtitle = spec.subtitle;
  if (spec.seeAll && spec.seeAll.id) {
    section.seeAllTarget = {
      type: "category",
      category: {
        id: String(spec.seeAll.id),
        parentId: String(spec.seeAll.parentId || ""),
        title: String(spec.seeAll.title || spec.title || ""),
        icon: String(spec.seeAll.icon || ""),
        biz: String(spec.seeAll.biz || "")
      }
    };
  }
  return section;
}

async function _douyu_buildHomeFeed() {
  const extraSpecs = [
    { id: "lol", title: "英雄联盟", cateId: "1", seeAll: { id: "1", parentId: "1", title: "英雄联盟" } },
    { id: "wzry", title: "王者荣耀", cateId: "181", seeAll: { id: "181", parentId: "9", title: "王者荣耀" } },
    { id: "xingxiu", title: "星秀", cateId: "1008", seeAll: { id: "1008", parentId: "2", title: "星秀" } }
  ];

  const fetched = await Promise.all([
    _douyu_getHomeSlideItems(),
    _douyu_getHomeRoomList("0")
  ].concat(extraSpecs.map(function (spec) {
    return _douyu_getHomeRoomList(spec.cateId).then(
      function (rooms) { return rooms; },
      function () { return []; }
    );
  })));
  const slideItems = fetched[0];
  const hot = fetched[1];
  const extraLists = fetched.slice(2);
  if (!hot.length) {
    _douyu_throw("INVALID_RESPONSE", "home feed hot list empty", {});
  }

  const banners = _douyu_collectHomeSlideBanners(slideItems);

  const sections = [];
  const hotSection = _douyu_homeSection({
    id: "hot",
    title: "热门直播",
    seeAll: { id: "0", parentId: "", title: "热门直播" }
  }, hot);
  if (hotSection) sections.push(hotSection);

  for (let i = 0; i < extraSpecs.length; i += 1) {
    const section = _douyu_homeSection(extraSpecs[i], extraLists[i]);
    if (section) sections.push(section);
  }

  const revisionParts = [];
  for (let i = 0; i < banners.length; i += 1) revisionParts.push(banners[i].id);
  for (let i = 0; i < sections.length; i += 1) {
    const first = sections[i].items[0];
    revisionParts.push(sections[i].id + ":" + ((first && first.id) || "0"));
  }

  return {
    schemaVersion: 1,
    revision: revisionParts.join("|").slice(0, 256),
    generatedAt: new Date().toISOString(),
    ttlSeconds: __douyu_homeTTLSeconds,
    banners: banners,
    sections: sections
  };
}

async function _douyu_getRoomDetail(roomId) {
  const url = `https://www.douyu.com/betard/${encodeURIComponent(String(roomId))}`;
  const resp = await Host.http.request({
    url,
    method: "GET",
    headers: {
      referer: `https://www.douyu.com/${String(roomId)}`,
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43"
    },
    timeout: 20
  });

  const obj = JSON.parse(resp.bodyText || "{}");
  const room = (obj && obj.room) || null;
  if (!room) _douyu_throw("INVALID_RESPONSE", "missing room field", { roomId: String(roomId || "") });

  const showStatus = room.show_status != null ? Number(room.show_status) : -1;
  const videoLoop = room.videoLoop != null ? Number(room.videoLoop) : -1;

  let liveState = "0";
  if (showStatus === 1 && videoLoop === 0) {
    liveState = "1";
  } else if ((showStatus === 0 && videoLoop === 1) || (showStatus === 1 && videoLoop === 1)) {
    liveState = "2";
  } else {
    liveState = "0";
  }

  const roomBizAll = room.room_biz_all || {};
  return {
    userName: String(room.nickname || ""),
    roomTitle: String(room.room_name || ""),
    roomCover: String(room.room_pic || ""),
    userHeadImg: String(room.owner_avatar || ""),
    liveType: "3",
    liveState,
    userId: String(room.owner_uid || room.owner_id || "0"),
    roomId: String(roomId),
    liveWatchedCount: String(roomBizAll.hot || "")
  };
}

function _douyu_responseDateSeconds(response) {
  const headers = (response && response.headers) || {};
  let date = "";
  for (const name of Object.keys(headers)) {
    if (String(name).toLowerCase() === "date") {
      date = String(headers[name] || "");
      break;
    }
  }
  const parsed = date ? Date.parse(date) : NaN;
  return String(Math.floor((Number.isFinite(parsed) ? parsed : Date.now()) / 1000));
}

async function _douyu_playbackRequest(request, auth) {
  return await Host.http.request({
    platformId: "douyu",
    authMode: auth.mode,
    request
  });
}

function _douyu_playbackJSON(response, auth, endpoint) {
  const status = Number(response && (response.statusCode || response.status) || 200);
  const loginRedirect = /\/\/passport\.douyu\.com\/member\/login(?:[/?#]|$)/i.test(String(response && response.url || ""));
  if (status >= 300 || loginRedirect) {
    auth.retryAsGuest = auth.mode === "platform_cookie" && (status === 401 || status === 403 || loginRedirect);
    _douyu_throw("INVALID_RESPONSE", endpoint + " failed", { httpStatus: String(status) });
  }
  let obj;
  try { obj = JSON.parse(response && response.bodyText || ""); } catch (error) {
    _douyu_throw("INVALID_RESPONSE", endpoint + " did not return valid JSON");
  }
  const upstreamCode = obj && obj.error;
  if (upstreamCode == null || String(upstreamCode).trim() === "" || !Number.isFinite(Number(upstreamCode)) || Number(upstreamCode) !== 0) {
    // A nonzero API response may depend on the stored session. Retry once as
    // a guest without declaring that an unknown upstream code means expiry.
    auth.retryAsGuest = auth.mode === "platform_cookie"
      && upstreamCode != null && String(upstreamCode).trim() !== ""
      && Number.isFinite(Number(upstreamCode)) && Number(upstreamCode) !== 0;
    _douyu_throw("INVALID_RESPONSE", endpoint + " failed", { upstreamCode: String(upstreamCode) });
  }
  return obj;
}

function _douyu_guestPlaybackNotice() {
  console.log("[douyu] 登录态取流不可用，尝试游客播放；登录画质请重新登录斗鱼");
}

const _douyu_loginChallenges = {};
const _douyu_loginHeaders = {
  Referer: "https://passport.douyu.com/member/login",
  "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
  "X-Requested-With": "XMLHttpRequest"
};

function _douyu_loginJSON(body) {
  const text = String(body || "").trim();
  const match = text.match(/^[\w$.]+\((\{[\s\S]*\})\);?$/);
  const json = text[0] === "{" ? text : match && match[1];
  try { return JSON.parse(json || "{}"); } catch (error) { return {}; }
}

async function _douyu_loginTransactionRequest(transactionId, request) {
  return await Host.http.request({
    platformId: "douyu",
    authMode: "login_transaction",
    transactionId,
    request
  });
}

function _douyu_loginChallenge(payload) {
  const challengeId = String(payload && payload.challengeId || "");
  const transactionId = String(payload && payload.transactionId || "");
  const challenge = _douyu_loginChallenges[challengeId];
  if (!challenge || challenge.transactionId !== transactionId) {
    _douyu_throw("INVALID_ARGS", "login challenge is missing or expired");
  }
  return challenge;
}

async function _douyu_createLoginChallenge(payload) {
  if (!Host.capabilities || Host.capabilities.loginTransaction !== true) {
    _douyu_throw("UNSUPPORTED", "host login transaction is unavailable");
  }
  const transactionId = String(payload && payload.transactionId || "");
  if (!transactionId) _douyu_throw("INVALID_ARGS", "transactionId is required");
  const resp = await _douyu_loginTransactionRequest(transactionId, {
    url: "https://passport.douyu.com/scan/generateCode",
    method: "POST",
    headers: Object.assign({}, _douyu_loginHeaders, { "Content-Type": "application/x-www-form-urlencoded" }),
    body: "client_id=1&isMultiAccount=0",
    timeout: 20
  });
  const obj = _douyu_loginJSON(resp && resp.bodyText);
  const data = obj && obj.data || {};
  if (Number(obj.error) !== 0 || !data.code || !/^https:\/\//.test(String(data.url || ""))) {
    _douyu_throw("UPSTREAM", "douyu QR creation failed");
  }
  const challengeId = `douyu-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  _douyu_loginChallenges[challengeId] = { transactionId, code: String(data.code) };
  const expires = Number(data.expire);
  return {
    kind: "qrcode",
    challengeId,
    qrContent: String(data.url),
    pollIntervalMs: 2000,
    expiresAt: Number.isFinite(expires) && expires > 0 ? Date.now() + expires * 1000 : 0,
    hint: "打开斗鱼 App，在我的页面扫描二维码并确认登录"
  };
}

async function _douyu_pollLoginChallenge(payload) {
  const challenge = _douyu_loginChallenge(payload);
  const url = `https://passport.douyu.com/japi/scan/auth?time=${Date.now()}&code=${encodeURIComponent(challenge.code)}`;
  const resp = await _douyu_loginTransactionRequest(challenge.transactionId, {
    url, method: "GET", headers: _douyu_loginHeaders, timeout: 20
  });
  const obj = _douyu_loginJSON(resp && resp.bodyText);
  const rawStatus = Number(obj.error);
  if (rawStatus === -1) {
    delete _douyu_loginChallenges[String(payload.challengeId)];
    return { state: "expired", rawStatus };
  }
  if (rawStatus === 1) return { state: "scanned", rawStatus };
  if (rawStatus !== 0) return { state: "waiting", rawStatus: Number.isFinite(rawStatus) ? rawStatus : null };
  const callbackURL = String(obj.data && obj.data.url || "");
  if (!/^https:\/\/(?:[a-z0-9-]+\.)*douyu\.com(?:[/:?#]|$)/i.test(callbackURL)) {
    return { state: "failed", rawStatus, message: "斗鱼登录完成地址无效" };
  }
  const completionURL = /[?&]callback=/.test(callbackURL)
    ? callbackURL : `${callbackURL}${callbackURL.indexOf("?") >= 0 ? "&" : "?"}callback=appClient_json_callback`;
  const finish = await _douyu_loginTransactionRequest(challenge.transactionId, {
    url: completionURL, method: "GET",
    headers: { Referer: _douyu_loginHeaders.Referer, "User-Agent": _douyu_loginHeaders["User-Agent"] },
    timeout: 20
  });
  const finishObject = _douyu_loginJSON(finish && finish.bodyText);
  if (Number(finishObject.error) !== 0) {
    return { state: "failed", rawStatus, message: "斗鱼扫码登录完成失败" };
  }
  delete _douyu_loginChallenges[String(payload.challengeId)];
  return { state: "confirmed", rawStatus };
}

// The host scopes this legacy getter to the owning plugin and to the candidate
// credential during validation. Never copy the Cookie into requests or errors.
function _douyu_sessionFields() {
  if (!Host.session || typeof Host.session.getCookieHeader !== "function") return null;
  try {
    const cookie = Host.session.getCookieHeader("douyu");
    if (typeof cookie !== "string") return null;
    const fields = {};
    for (const part of cookie.split(";")) {
      const separator = part.indexOf("=");
      if (separator < 1) continue;
      const name = part.slice(0, separator).trim();
      if (!/^(?:acf_did|dy_did|acf_auth|dy_auth|acf_jwt_token)$/.test(name)) continue;
      fields[name] = part.slice(separator + 1).trim();
    }
    return fields;
  } catch (error) {
    return null;
  }
}

function _douyu_playbackTokenExpiry(fields) {
  if (!fields || !fields.acf_jwt_token) return 0;
  try {
    const parts = fields.acf_jwt_token.split(".");
    if (parts.length !== 3) return 0;
    let encoded = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    while (encoded.length % 4) encoded += "=";
    const decoded = Host.crypto && typeof Host.crypto.base64Decode === "function"
      ? Host.crypto.base64Decode(encoded)
      : (typeof atob === "function" ? atob(encoded) : "");
    const expiry = JSON.parse(decoded).exp;
    return Number.isSafeInteger(expiry) && expiry > 0 ? expiry : 0;
  } catch (error) {
    return 0;
  }
}

function _douyu_playbackAuthorization(fields, nowSeconds) {
  if (!fields) return null; // Older hosts can still validate through the API.
  const expiry = _douyu_playbackTokenExpiry(fields);
  if (!expiry) {
    return { state: "invalid", expireAt: 0, message: "斗鱼播放授权不完整，请重新登录以更新完整 Cookie" };
  }
  if (expiry <= nowSeconds) {
    return { state: "expired", expireAt: expiry, message: "斗鱼播放授权已过期，请重新登录" };
  }
  return { state: "valid", expireAt: expiry, message: "" };
}

function _douyu_playbackDid(fields) {
  for (const value of fields ? [fields.acf_did, fields.dy_did] : []) {
    if (typeof value === "string" && /^[a-z0-9]{16,64}$/i.test(value)) return value;
  }
  return "10000000000000000000000000001501";
}

async function _douyu_validateCredential(payload) {
  if (!payload || payload.credentialAvailable !== true) {
    return { state: "missing", expireAt: 0, userId: "", userName: "", message: "斗鱼登录凭据不可用" };
  }
  const resp = await Host.http.request({
    platformId: "douyu",
    authMode: "platform_cookie",
    request: {
      url: `https://www.douyu.com/lapi/member/api/getInfo?client_type=0&d=${Date.now()}`,
      method: "GET",
      headers: { "User-Agent": _douyu_loginHeaders["User-Agent"], Referer: "https://www.douyu.com/", Accept: "application/json" },
      followRedirects: false,
      timeout: 20
    }
  });
  const status = Number(resp && (resp.statusCode || resp.status));
  if (status === 401 || (status >= 300 && status < 400) || /\/\/passport\.douyu\.com\/member\/login(?:[/?#]|$)/i.test(String(resp && resp.url || ""))) {
    return { state: "expired", expireAt: 0, userId: "", userName: "", message: "斗鱼登录状态已失效，请重新登录" };
  }
  // A challenge, HTML page or upstream outage cannot establish a login. Report
  // an unavailable check without discarding an otherwise usable stored session.
  if (status !== 200) _douyu_throw("NETWORK", "暂时无法确认斗鱼登录状态，请稍后重试");
  let obj;
  try { obj = JSON.parse(resp.bodyText || ""); } catch (error) {
    _douyu_throw("NETWORK", "斗鱼账号校验未返回有效 JSON，请稍后重试");
  }
  if (obj && Number(obj.error) === 1) {
    return { state: "expired", expireAt: 0, userId: "", userName: "", message: "斗鱼登录状态已失效，请重新登录" };
  }
  const account = obj && obj.msg;
  const userId = String(account && account.uid || "");
  if (Number(obj && obj.error) !== 0 || !/^[1-9]\d*$/.test(userId)) {
    _douyu_throw("NETWORK", "斗鱼账号校验未确认用户身份，请稍后重试");
  }
  const authorization = _douyu_playbackAuthorization(_douyu_sessionFields(), Number(_douyu_responseDateSeconds(resp)));
  return {
    state: authorization ? authorization.state : "valid",
    expireAt: authorization ? authorization.expireAt : 0,
    userId, userName: String(account.info && account.info.nn || ""),
    message: authorization ? authorization.message : ""
  };
}

async function _douyu_getEncryption(did, auth) {
  const encResp = await _douyu_playbackRequest({
    url: `https://www.douyu.com/wgapi/livenc/liveweb/websec/getEncryption?did=${encodeURIComponent(did)}`,
    method: "GET",
    headers: {
      referer: "https://www.douyu.com/",
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43"
    },
    timeout: 20
  }, auth);
  const encObj = _douyu_playbackJSON(encResp, auth, "getEncryption");
  const data = encObj && encObj.data;
  if (Number(encObj && encObj.error) !== 0 || !data || !data.key || !data.rand_str || !data.enc_data) {
    _douyu_throw("INVALID_RESPONSE", "getEncryption failed", { upstreamCode: String(encObj && encObj.error) });
  }
  const iterations = Number(data.enc_time);
  if (data.enc_time == null || String(data.enc_time).trim() === "" || !Number.isSafeInteger(iterations) || iterations < 0 || iterations > 10000) {
    const hint = data.enc_time == null ? "missing" : Number.isFinite(iterations) ? String(iterations) : typeof data.enc_time;
    _douyu_throw("INVALID_RESPONSE", `invalid encryption iteration count (${hint})`);
  }
  return { data, timestamp: _douyu_responseDateSeconds(encResp) };
}

function _douyu_confirmedRate(value) {
  if (typeof value !== "string" && typeof value !== "number") return null;
  const text = String(value).trim();
  if (!/^\d+$/.test(text)) return null;
  const rate = Number(text);
  return Number.isSafeInteger(rate) ? rate : null;
}

async function _douyu_getPlayback(roomId, rate, cdn, resolveSelection) {
  const fields = _douyu_sessionFields();
  const hasCredential = fields && (fields.acf_auth || fields.dy_auth || fields.acf_jwt_token);
  // Known incomplete credentials must not poison even the encryption request.
  // A valid-looking JWT is checked against server time below, not device time.
  const incomplete = hasCredential && !_douyu_playbackTokenExpiry(fields);
  const auth = { mode: incomplete ? "none" : "platform_cookie", retryAsGuest: false };
  if (incomplete) _douyu_guestPlaybackNotice();
  try {
    return await _douyu_fetchPlayback(roomId, rate, cdn, resolveSelection, fields, auth);
  } catch (error) {
    if (!auth.retryAsGuest) throw error;
    _douyu_guestPlaybackNotice();
    // Start again with guest encryption and DID. Do not clear the host's
    // credential or retain guest mode after the user renews their login.
    return await _douyu_fetchPlayback(roomId, rate, cdn, resolveSelection, null, { mode: "none", retryAsGuest: false });
  }
}

async function _douyu_fetchPlayback(roomId, rate, cdn, resolveSelection, fields, auth) {
  const did = _douyu_playbackDid(auth.mode === "none" ? null : fields);
  const encryption = await _douyu_getEncryption(did, auth);
  if (auth.mode === "platform_cookie" && fields && (fields.acf_auth || fields.dy_auth || fields.acf_jwt_token)) {
    const authorization = _douyu_playbackAuthorization(fields, Number(encryption.timestamp));
    if (authorization && authorization.state !== "valid") {
      auth.retryAsGuest = true;
      _douyu_throw("AUTH_REQUIRED", authorization.message);
    }
  }
  const encData = encryption.data;
  const tt = encryption.timestamp;
  let value = String(encData.rand_str);
  for (let i = 0; i < Number(encData.enc_time); i += 1) {
    value = Host.crypto.md5(value + String(encData.key));
  }
  const suffix = Number(encData.is_special) === 1 ? "" : String(roomId) + tt;
  const authHash = Host.crypto.md5(value + String(encData.key) + suffix);
  const params = {
    enc_data: String(encData.enc_data), tt, did, auth: authHash,
    cdn: String(cdn || ""), rate: String(rate || 0), hevc: "0", fa: "0", ive: "0"
  };

  const body = Object.keys(params)
    .map(function (k) { return `${encodeURIComponent(k)}=${encodeURIComponent(String(params[k] || ""))}`; })
    .join("&");

  const resp = await _douyu_playbackRequest({
    url: `https://www.douyu.com/lapi/live/getH5PlayV1/${encodeURIComponent(String(roomId))}`,
    method: "POST",
    headers: {
      referer: `https://www.douyu.com/${String(roomId)}`,
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43",
      "content-type": "application/x-www-form-urlencoded"
    },
    body,
    timeout: 20
  }, auth);

  const obj = _douyu_playbackJSON(resp, auth, "getH5PlayV1");
  const data = obj && obj.data;
  if (Number(obj && obj.error) !== 0 || !data) {
    _douyu_throw("INVALID_RESPONSE", "getH5PlayV1 failed", { roomId: String(roomId || ""), upstreamCode: String(obj && obj.error) });
  }

  const multirates = data.multirates || [];
  const cdns = data.cdnsWithName || [];
  const rtmpUrl = String(data.rtmp_url || "");
  const rtmpLive = String(data.rtmp_live || "");
  if (!/^https?:\/\//i.test(rtmpUrl) || !rtmpLive) {
    _douyu_throw("INVALID_RESPONSE", "getH5PlayV1 returned no stream");
  }
  const playUrl = `${rtmpUrl}/${rtmpLive}`;
  const actualRate = _douyu_confirmedRate(data.rate);
  const actualMeta = multirates.find(function (q) {
    return q && actualRate !== null && _douyu_confirmedRate(q.rate) === actualRate;
  });
  // The initial list is a menu of deferred requests (refreshOnSelect).
  // A resolved selection must describe the response, including downgrades.
  const choices = resolveSelection ? [{
    rate: actualRate === null ? -1 : actualRate,
    name: actualRate === null ? "清晰度未确认"
      : (actualMeta && actualMeta.name ? String(actualMeta.name) : `清晰度 ${actualRate}`)
  }] : multirates;

  const out = [];
  for (const cdnItem of cdns) {
    const serverCdn = String(cdnItem.cdn || "");
    if (cdn && serverCdn !== String(cdn)) continue;
    const playbackHeaders = { "User-Agent": _douyu_playbackUserAgent, Referer: "https://www.douyu.com/" };

    const qualitys = choices.map(function (q) {
      return {
        roomId: String(roomId),
        title: String(q.name || ""),
        qn: Number(q.rate || 0),
        url: playUrl,
        liveCodeType: "flv",
        liveType: "3",
        userAgent: _douyu_playbackUserAgent,
        headers: playbackHeaders,
        requestContext: {
          rate: String(resolveSelection ? rate : (q.rate || 0)),
          qn: String(resolveSelection ? rate : (q.rate || 0))
        },
        playbackHints: {
          streamFormat: "flv",
          selectionBehavior: "refreshOnSelect"
        }
      };
    });

    out.push({
      cdn: String(cdnItem.name || ""),
      displayName: String(cdnItem.name || serverCdn || ""),
      requestContext: { cdn: serverCdn },
      qualitys
    });
  }
  return out;
}

async function _douyu_search(keyword, page) {
  const did = _lp_randomString(32);
  const qs = [
    `kw=${encodeURIComponent(String(keyword))}`,
    `page=${encodeURIComponent(String(page))}`,
    "pageSize=20"
  ].join("&");

  const resp = await Host.http.request({
    url: `https://www.douyu.com/japi/search/api/searchShow?${qs}`,
    method: "GET",
    headers: {
      referer: "https://www.douyu.com/search/",
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43",
      Cookie: `dy_did=${did};acf_did=${did}`
    },
    timeout: 20
  });

  const obj = JSON.parse(resp.bodyText || "{}");
  const list = (obj && obj.data && obj.data.relateShow) || [];
  return list.map(function (item) {
    return {
      userName: String(item.nickName || ""),
      roomTitle: String(item.roomName || ""),
      roomCover: String(item.roomSrc || ""),
      userHeadImg: String(item.avatar || ""),
      liveType: "3",
      liveState: Number(item.roomType || 1) === 0 ? "1" : "0",
      userId: String(item.rid || ""),
      roomId: String(item.rid || ""),
      liveWatchedCount: String(item.hot || "")
    };
  });
}

async function _douyu_resolveShare(shareCode) {
  const input = String(shareCode || "").trim();
  if (!input) _douyu_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });

  let fallbackRoomId = "";
  let candidateUrl = "";
  if (_lp_isNumericId(input)) {
    fallbackRoomId = input;
    candidateUrl = `https://www.douyu.com/${input}`;
  }

  if (input.includes("douyu.com") || input.includes("douyu.tv")) {
    candidateUrl = _lp_firstURL(input) || candidateUrl;
    fallbackRoomId = _lp_firstMatch(input, /douyu\.(?:com|tv)\/(\d+)/) || fallbackRoomId;
    fallbackRoomId = _lp_firstMatch(input, /rid=(\d+)/) || fallbackRoomId;
  }

  if (!candidateUrl) {
    if (input.startsWith("http")) {
      candidateUrl = input;
    } else if (input.includes("douyu")) {
      candidateUrl = `https://www.douyu.com/${input}`;
    }
  }

  if (candidateUrl) {
    const resp = await Host.http.request({
      url: candidateUrl,
      method: "GET",
      timeout: 20
    });

    let roomId = _douyu_extractRoomIdFromPage(resp.bodyText || "");
    if (_lp_isNumericId(roomId)) return roomId;

    roomId = _lp_firstMatch(resp.url || "", /(?:douyu\.(?:com|tv)\/|rid=)(\d+)/);
    if (_lp_isNumericId(roomId)) return roomId;

    const html = String(resp.bodyText || "");
    const patterns = [
      /"room_id":\s*(\d+)/,
      /"rid":\s*"?(\d+)/,
      /roomId\s*[:=]\s*"?(\d+)/
    ];

    for (const p of patterns) {
      roomId = _lp_firstMatch(html, p);
      if (_lp_isNumericId(roomId)) return roomId;
    }
  }

  if (_lp_isNumericId(fallbackRoomId)) return fallbackRoomId;

  _douyu_throw("NOT_FOUND", "roomId not found", { shareCode: String(shareCode || "") });
}

const __douyu_sharedGlobalKey = "__lp_plugin_douyu_1_0_4_shared";

function _douyu_danmakuDriver() {
  const driver = globalThis.__douyuDanmakuDriver;
  if (!driver) {
    _douyu_throw("UNSUPPORTED", "douyu danmaku driver is unavailable", {});
  }
  return driver;
}

globalThis[__douyu_sharedGlobalKey] = {
  throwError: _douyu_throw
};

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async validateCredential(payload) {
    return await _douyu_validateCredential(payload);
  },

  async createLoginChallenge(payload) {
    return await _douyu_createLoginChallenge(payload);
  },

  async pollLoginChallenge(payload) {
    return await _douyu_pollLoginChallenge(payload);
  },

  async cancelLoginChallenge(payload) {
    delete _douyu_loginChallenges[String(payload && payload.challengeId || "")];
    return { ok: true };
  },

  async getCategories() {
    return await _douyu_getCategories();
  },

  async getRooms(payload) {
    const id = String(payload && payload.id ? payload.id : "");
    const page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _douyu_throw("INVALID_ARGS", "id is required", { field: "id" });
    return await _douyu_getRooms(id, page);
  },

  async getHomeFeed(payload) {
    return await _douyu_buildHomeFeed(payload || {});
  },

  async getPlayback(payload) {
    const roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _douyu_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    const requestedRate = Number((payload && (payload.rate !== undefined ? payload.rate : payload.qn)) || 0);
    const requestedCdn = String((payload && payload.cdn) || "").trim();
    return await _douyu_getPlayback(roomId, requestedRate, requestedCdn || null);
  },

  async refreshPlayback(payload) {
    const roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _douyu_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });

    const cdn = (payload && payload.cdn) || {};
    const quality = (payload && payload.quality) || {};
    const cdnContext = cdn.requestContext || {};
    const qualityContext = quality.requestContext || {};
    const requestedRate = Number(
      qualityContext.rate !== undefined ? qualityContext.rate
        : (qualityContext.qn !== undefined ? qualityContext.qn : (quality.qn || 0))
    );
    const requestedCdn = String(
      cdnContext.cdn || cdnContext.cdnId || cdn.cdn || ""
    ).trim();

    const refreshed = await _douyu_getPlayback(roomId, requestedRate, requestedCdn || null, true);
    let picked = null;
    for (const item of refreshed) {
      const qualitys = item && item.qualitys ? item.qualitys : [];
      if (qualitys.length > 0) {
        picked = qualitys[0];
        break;
      }
    }
    if (!picked) _douyu_throw("NOT_FOUND", "refreshed playback is empty", { roomId });

    return Object.assign({}, quality, picked, {
      requestContext: Object.assign({}, qualityContext, picked.requestContext || {})
    });
  },

  async getRoomDetail(payload) {
    const roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _douyu_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return await _douyu_getRoomDetail(roomId);
  },

  async getLiveState(payload) {
    const roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _douyu_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    const info = await _douyu_getRoomDetail(roomId);
    return {
      liveState: String(info && info.liveState ? info.liveState : "3")
    };
  },

  async search(payload) {
    const keyword = String(payload && payload.keyword ? payload.keyword : "");
    const page = payload && payload.page ? Number(payload.page) : 1;
    if (!keyword) _douyu_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return await _douyu_search(keyword, page);
  },

  async resolveShare(payload) {
    const shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _douyu_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    const roomId = await _douyu_resolveShare(shareCode);
    return await _douyu_getRoomDetail(roomId);
  },

  async getDanmaku(payload) {
    const roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _douyu_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return await _douyu_danmakuDriver().getDanmakuPlan(roomId);
  },

  async createDanmakuSession(payload) {
    return await _douyu_danmakuDriver().createDanmakuSession(payload);
  },

  async onDanmakuOpen(payload) {
    return await _douyu_danmakuDriver().onDanmakuOpen(payload);
  },

  async onDanmakuFrame(payload) {
    return await _douyu_danmakuDriver().onDanmakuFrame(payload);
  },

  async onDanmakuTick(payload) {
    return await _douyu_danmakuDriver().onDanmakuTick(payload);
  },

  async destroyDanmakuSession(payload) {
    return await _douyu_danmakuDriver().destroyDanmakuSession(payload);
  }
};
