(function () {
const __douyu_danmakuSessions = {};
const __douyu_sharedGlobalKey = "__lp_plugin_douyu_1_0_4_shared";
const __douyu_proxyPorts = [8501, 8502, 8503, 8504, 8505, 8506];
const __douyu_heartbeatIntervalMs = 30000;
const __douyu_connectionUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43";
// Values mirrored from douyu web live-next loginConfig (common_*.js).
const __douyu_loginVersion = "20220825";
const __douyu_countVersion = "218101901";
const __douyu_defaultGid = "-9999";

const __douyu_emojiMapFallback = {
  "dy001": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy001_4ec83b2.png",
  "dy002": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy002_8c5b741.png",
  "dy003": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy003_a2cf203.png",
  "dy004": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy004_1ae2ed4.png",
  "dy005": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy005_44b8727.png",
  "dy006": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy006_41e3330.png",
  "dy007": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy007_5d6ce88.png",
  "dy008": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy008_3879aa5.png",
  "dy009": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy009_7c79af6.png",
  "dy010": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy010_7ca1dca.png",
  "dy011": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy011_24ecb9c.png",
  "dy012": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy012_2f0045c.png",
  "dy013": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy013_d6e5900.png",
  "dy014": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy014_63e7ba3.png",
  "dy015": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy015_22b67ae.png",
  "dy016": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy016_bc63e7c.png",
  "dy017": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy017_500182f.png",
  "dy101": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy101_71e7dac.png",
  "dy102": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy102_37409b6.png",
  "dy103": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy103_389648d.png",
  "dy104": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy104_2bbdefb.png",
  "dy105": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy105_b54585b.png",
  "dy106": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy106_dea7a1e.png",
  "dy107": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy107_ef6f4b6.png",
  "dy108": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy108_6d5245b.png",
  "dy109": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy109_3ac1a68.png",
  "dy110": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy110_1615dc5.png",
  "dy111": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy111_3a5b1bf.png",
  "dy112": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy112_c9017f8.png",
  "dy113": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy113_8c46400.png",
  "dy114": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy114_7cb1573.png",
  "dy115": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy115_cd7a391.png",
  "dy116": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy116_ca9b9f0.png",
  "dy117": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy117_a7ef970.png",
  "dy118": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy118_bf2da42.png",
  "dy119": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy119_64b8a96.png",
  "dy120": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy120_28b1930.png",
  "dy121": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy121_bc69d53.png",
  "dy122": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy122_6d588a0.png",
  "dy123": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy123_38dcd41.png",
  "dy124": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy124_a11e534.png",
  "dy125": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy125_963fdcf.png",
  "dy126": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy126_1bed031.png",
  "dy127": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy127_2b0e153.png",
  "dy128": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy128_b16c716.png",
  "dy129": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy129_f88266f.png",
  "dy130": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy130_4783223.png",
  "dy131": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy131_9a30a32.png",
  "dy132": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy132_8105357.png",
  "dy133": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy133_29e04b0.png",
  "dy134": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy134_d13cf33.png",
  "dy135": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy135_08d2070.png",
  "dy136": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy136_bde1915.png",
  "dy137": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy137_37a4376.png",
  "dy138": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy138_765b6e7.gif",
  "dy139": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy139_da724ff.gif",
  "dy140": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy140_6530aa1.gif",
  "dy141": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy141_2bcd2d2.gif",
  "dy142": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy142_5561994.gif",
  "dy143": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy143_92f0acd.gif",
  "dy144": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy144_b9811ab.gif",
  "dy145": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy145_fc15660.gif",
  "dy146": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy146_acaf43b.gif",
  "dy147": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy147_35628a7.gif",
  "dy148": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy148_018514b.gif",
  "dy149": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy149_f318c1d.gif",
  "dy150": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy150_10d4092.gif",
  "dy151": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy151_baec82e.gif",
  "dy152": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy152_5c56a62.gif",
  "dy153": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy153_888932d.gif",
  "dy154": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy154_063438b.gif",
  "dy155": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy155_137c5ee.gif",
  "dy156": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy156_3c484e6.gif",
  "dy157": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy157_bf41d90.gif",
  "dy158": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy158_291bb31.gif",
  "dy159": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy159_f4e2bda.gif",
  "dy160": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy160_2dfe373.gif",
  "dy161": "https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy161_76f0f95.gif"
};
const __douyu_emojiNameToCode = {
  "[666]": "dy101",
  "[发呆]": "dy102",
  "[拜拜]": "dy103",
  "[晕]": "dy104",
  "[弱]": "dy105",
  "[傲慢]": "dy106",
  "[开心]": "dy107",
  "[奋斗]": "dy108",
  "[很酷]": "dy109",
  "[流泪]": "dy110",
  "[鄙视]": "dy111",
  "[得意]": "dy112",
  "[抠鼻]": "dy113",
  "[亲亲]": "dy114",
  "[偷笑]": "dy115",
  "[口罩]": "dy116",
  "[委屈]": "dy117",
  "[难过]": "dy118",
  "[吐血]": "dy119",
  "[大怒]": "dy120",
  "[赞]": "dy121",
  "[睡觉]": "dy122",
  "[骷髅]": "dy123",
  "[调皮]": "dy124",
  "[惊讶]": "dy125",
  "[撇嘴]": "dy126",
  "[拥抱]": "dy127",
  "[背锅]": "dy128",
  "[闭嘴]": "dy129",
  "[吃药]": "dy130",
  "[可怜]": "dy131",
  "[呕吐]": "dy132",
  "[敲打]": "dy133",
  "[心碎]": "dy134",
  "[嘘]": "dy135",
  "[中箭]": "dy136",
  "[抓狂]": "dy137",
  "[流汗]": "dy001",
  "[丢药]": "dy002",
  "[白眼]": "dy003",
  "[火箭]": "dy004",
  "[色]": "dy005",
  "[点蜡]": "dy006",
  "[抽烟]": "dy007",
  "[可爱]": "dy008",
  "[炸弹]": "dy009",
  "[吃丸子]": "dy010",
  "[害怕]": "dy011",
  "[疑问]": "dy012",
  "[阴险]": "dy013",
  "[害羞]": "dy014",
  "[笑哭]": "dy015",
  "[猪头]": "dy016",
  "[困]": "dy017"
};

let __douyu_emojiMap = null;
let __douyu_emojiMapPromise = null;
const __douyu_emojiRoomPageBase = "https://www.douyu.com/";
const __douyu_emojiUserAgent = __douyu_connectionUserAgent;
const __douyu_webEmotionURL = "https://msg.douyu.com/wbapi/web/emotion?timestamp=0";
const __douyu_dfansEmojisURL = "https://www.douyu.com/japi/interact/comm/dfans/emojis?rid=";

function _douyu_shared() {
  const shared = globalThis[__douyu_sharedGlobalKey];
  if (!shared) {
    throw new Error("LP_PLUGIN_ERROR:{\"code\":\"UNSUPPORTED\",\"message\":\"douyu shared helpers are unavailable\",\"context\":{}}");
  }
  return shared;
}

function _douyu_throw(code, message, context) {
  const shared = globalThis[__douyu_sharedGlobalKey];
  if (shared && typeof shared.throwError === "function") {
    return shared.throwError(code, message, context || {});
  }
  throw new Error(`LP_PLUGIN_ERROR:${JSON.stringify({ code: String(code || "UNKNOWN"), message: String(message || ""), context: context || {} })}`);
}

function _douyu_str(value) {
  return value === undefined || value === null ? "" : String(value);
}

function _douyu_u8(value) {
  return value & 0xff;
}

function _douyu_u32LE(value) {
  const v = Number(value) >>> 0;
  return [v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff];
}

function _douyu_utf8Encode(text) {
  const input = _douyu_str(text);
  const out = [];
  for (let i = 0; i < input.length; i += 1) {
    const c = input.charCodeAt(i);
    if (c < 0x80) {
      out.push(c);
    } else if (c < 0x800) {
      out.push(0xc0 | (c >> 6));
      out.push(0x80 | (c & 0x3f));
    } else if (c >= 0xd800 && c <= 0xdbff) {
      i += 1;
      if (i >= input.length) break;
      const c2 = input.charCodeAt(i);
      const u = 0x10000 + ((c & 0x3ff) << 10) + (c2 & 0x3ff);
      out.push(0xf0 | (u >> 18));
      out.push(0x80 | ((u >> 12) & 0x3f));
      out.push(0x80 | ((u >> 6) & 0x3f));
      out.push(0x80 | (u & 0x3f));
    } else {
      out.push(0xe0 | (c >> 12));
      out.push(0x80 | ((c >> 6) & 0x3f));
      out.push(0x80 | (c & 0x3f));
    }
  }
  return out;
}

function _douyu_utf8Decode(bytes) {
  const input = Array.isArray(bytes) ? bytes : [];
  let out = "";
  let i = 0;
  while (i < input.length) {
    const c = input[i++] & 0xff;
    if ((c & 0x80) === 0) {
      out += String.fromCharCode(c);
    } else if ((c & 0xe0) === 0xc0) {
      if (i >= input.length) break;
      const c2 = input[i++] & 0x3f;
      out += String.fromCharCode(((c & 0x1f) << 6) | c2);
    } else if ((c & 0xf0) === 0xe0) {
      if (i + 1 >= input.length) break;
      const c21 = input[i++] & 0x3f;
      const c22 = input[i++] & 0x3f;
      out += String.fromCharCode(((c & 0x0f) << 12) | (c21 << 6) | c22);
    } else {
      if (i + 2 >= input.length) break;
      const c31 = input[i++] & 0x3f;
      const c32 = input[i++] & 0x3f;
      const c33 = input[i++] & 0x3f;
      let u = ((c & 0x07) << 18) | (c31 << 12) | (c32 << 6) | c33;
      u -= 0x10000;
      out += String.fromCharCode(0xd800 + ((u >> 10) & 0x3ff));
      out += String.fromCharCode(0xdc00 + (u & 0x3ff));
    }
  }
  return out;
}

function _douyu_bytesToBase64(bytes) {
  if (typeof btoa !== "function") _douyu_throw("UNSUPPORTED", "btoa is unavailable", {});
  let binary = "";
  for (let i = 0; i < bytes.length; i += 1) binary += String.fromCharCode(bytes[i] & 0xff);
  return btoa(binary);
}

function _douyu_base64ToBytes(value) {
  if (typeof atob !== "function") _douyu_throw("UNSUPPORTED", "atob is unavailable", {});
  const raw = atob(_douyu_str(value));
  const out = [];
  for (let i = 0; i < raw.length; i += 1) out.push(raw.charCodeAt(i) & 0xff);
  return out;
}

function _douyu_binaryWrite(bytes) {
  return {
    kind: "binary",
    bytesBase64: _douyu_bytesToBase64(bytes)
  };
}

function _douyu_timer() {
  return {
    mode: "heartbeat",
    intervalMs: __douyu_heartbeatIntervalMs
  };
}

function _douyu_readInt32LE(bytes, index) {
  return (bytes[index] & 0xff)
    | ((bytes[index + 1] & 0xff) << 8)
    | ((bytes[index + 2] & 0xff) << 16)
    | ((bytes[index + 3] & 0xff) << 24);
}

function _douyu_escape(text) {
  return _douyu_str(text).replace(/@/g, "@A").replace(/\//g, "@S");
}

function _douyu_unescape(text) {
  return _douyu_str(text)
    .replace(/@S/g, "/")
    .replace(/@A/g, "@");
}

function _douyu_encodePacket(message) {
  const payload = _douyu_utf8Encode(_douyu_str(message));
  const totalLen = payload.length + 9;
  return []
    .concat(_douyu_u32LE(totalLen))
    .concat(_douyu_u32LE(totalLen))
    .concat([0xb1, 0x02, 0x00, 0x00])
    .concat(payload)
    .concat([0x00]);
}

function _douyu_pickField(message, key) {
  const escapedKey = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = new RegExp("(?:^|/)" + escapedKey + "@=([^/]*)/").exec(_douyu_str(message));
  return match && match[1] ? _douyu_unescape(match[1]) : "";
}

function _douyu_mapColor(raw) {
  switch (Number(raw)) {
    case 1: return 0xff0000;
    case 2: return 0x1e7df0;
    case 3: return 0x7ac84b;
    case 4: return 0xff7f00;
    case 5: return 0x9b39f4;
    case 6: return 0xff69b4;
    default: return 0xffffff;
  }
}

function _douyu_proxyUrlForPort(port) {
  return `wss://danmuproxy.douyu.com:${Number(port)}/`;
}

function _douyu_pickProxyUrl(roomId) {
  // Spread rooms across 8501-8506; add time salt so reconnects can land on another node.
  const rid = _douyu_str(roomId);
  let hash = 0;
  for (let i = 0; i < rid.length; i += 1) {
    hash = ((hash * 33) + rid.charCodeAt(i)) >>> 0;
  }
  const salt = Math.floor(Date.now() / 1000) % __douyu_proxyPorts.length;
  const index = (hash + salt + Math.floor(Math.random() * __douyu_proxyPorts.length)) % __douyu_proxyPorts.length;
  return _douyu_proxyUrlForPort(__douyu_proxyPorts[index]);
}

function _douyu_loginWrite(roomId) {
  // Align with web barrageLogin guest payload: roomid + dfl + ver/aver/ct + empty username/uid.
  const body = [
    "type@=loginreq",
    `roomid@=${_douyu_escape(roomId)}`,
    "dfl@=",
    "username@=",
    "uid@=0",
    `ver@=${_douyu_escape(__douyu_loginVersion)}`,
    `aver@=${_douyu_escape(__douyu_countVersion)}`,
    "ct@=0",
    ""
  ].join("/");
  return _douyu_binaryWrite(_douyu_encodePacket(body));
}

function _douyu_joinWrite(roomId, gid) {
  const groupId = _douyu_str(gid || "").trim() || __douyu_defaultGid;
  return _douyu_binaryWrite(
    _douyu_encodePacket(`type@=joingroup/rid@=${_douyu_escape(roomId)}/gid@=${_douyu_escape(groupId)}/`)
  );
}

function _douyu_heartbeatWrite() {
  return _douyu_binaryWrite(_douyu_encodePacket("type@=mrkl/"));
}

function _douyu_appendHeartbeat(session, writes) {
  writes.push(_douyu_heartbeatWrite());
  session.lastHeartbeatAt = Date.now();
}

function _douyu_appendHeartbeatIfDue(session, writes) {
  const now = Date.now();
  const last = Number(session && session.lastHeartbeatAt || 0);
  if (last > 0 && now - last < __douyu_heartbeatIntervalMs) return;
  _douyu_appendHeartbeat(session, writes);
}

function _douyu_decodePackets(bytes) {
  const input = Array.isArray(bytes) ? bytes : [];
  const packets = [];
  let offset = 0;
  while (offset + 12 <= input.length) {
    const packetLen = _douyu_readInt32LE(input, offset);
    const bodyLen = packetLen - 8;
    if (packetLen <= 0 || bodyLen <= 0 || offset + 4 + packetLen > input.length) break;
    const bodyStart = offset + 12;
    const bodyEnd = offset + 4 + packetLen;
    const body = input.slice(bodyStart, bodyEnd);
    const text = _douyu_utf8Decode(body).replace(/\u0000+$/g, "");
    if (text) {
      packets.push({
        type: _douyu_pickField(text, "type") || "",
        text: text
      });
    }
    offset += 4 + packetLen;
  }
  return packets;
}


function _douyu_pickAbsoluteHttpURL(value) {
  const text = _douyu_str(value).trim();
  if (!text) return "";
  if (text.indexOf("https://") === 0 || text.indexOf("http://") === 0) return text;
  return "";
}

function _douyu_cloneEmojiMap(source) {
  const out = {};
  const src = source && typeof source === "object" ? source : {};
  const keys = Object.keys(src);
  for (let i = 0; i < keys.length; i += 1) {
    const key = keys[i];
    const url = _douyu_pickAbsoluteHttpURL(src[key]);
    if (url) out[key] = url;
  }
  return out;
}

function _douyu_activeEmojiMap() {
  if (__douyu_emojiMap && typeof __douyu_emojiMap === "object") return __douyu_emojiMap;
  return __douyu_emojiMapFallback;
}

function _douyu_extractAsideAssetMap(jsText) {
  const source = _douyu_str(jsText);
  const map = {};
  // live-next-player-aside packs system faces as:
  // https://shark2.douyucdn.cn/front-publish/live-next-player-aside-master/assets/images/dy108_6d5245b.png
  const re = /https:\/\/shark2\.douyucdn\.cn\/front-publish\/live-next-player-aside-master\/assets\/images\/(dy\d+)_[a-f0-9]+\.(?:png|gif|webp|jpg)/gi;
  let match = re.exec(source);
  while (match) {
    const code = match[1];
    const url = match[0];
    if (code && url) map[code] = url;
    match = re.exec(source);
  }
  return map;
}

function _douyu_extractDeclarationURL(html) {
  const source = _douyu_str(html);
  const re = /https:\/\/shark2\.douyucdn\.cn\/front-publish\/smf-live-activity-common-pendant-master\/service-module-declaration_nc_[a-f0-9]+\.js/i;
  const m = source.match(re);
  if (m && m[0]) return m[0];
  const re2 = /smf-live-activity-common-pendant-master\/service-module-declaration_nc_[a-f0-9]+\.js/i;
  const m2 = source.match(re2);
  if (m2 && m2[0]) return "https://shark2.douyucdn.cn/front-publish/" + m2[0];
  return "";
}

function _douyu_extractAsideBundleURL(declarationText) {
  const source = _douyu_str(declarationText);
  const re = /https:\/\/shark2\.douyucdn\.cn\/front-publish\/live-next-player-aside-master\/js\/live-next-player-aside_[^"'\\\s]+\.js/i;
  const m = source.match(re);
  if (m && m[0]) return m[0];
  const re2 = /live-next-player-aside-master\/js\/live-next-player-aside_[^"'\\\s]+\.js/i;
  const m2 = source.match(re2);
  if (m2 && m2[0]) return "https://shark2.douyucdn.cn/front-publish/" + m2[0];
  return "";
}

async function _douyu_httpGetText(url, extraHeaders) {
  if (!globalThis.Host || !Host.http || typeof Host.http.request !== "function") {
    return "";
  }
  const headers = {
    "User-Agent": __douyu_emojiUserAgent,
    Referer: "https://www.douyu.com/",
    Accept: "*/*"
  };
  const extra = extraHeaders && typeof extraHeaders === "object" ? extraHeaders : {};
  const keys = Object.keys(extra);
  for (let i = 0; i < keys.length; i += 1) {
    headers[keys[i]] = extra[keys[i]];
  }
  try {
    const resp = await Host.http.request({
      platformId: "douyu",
      authMode: "none",
      request: {
        url: _douyu_str(url),
        method: "GET",
        headers: headers,
        timeout: 20
      }
    });
    return _douyu_str(resp && resp.bodyText);
  } catch (e) {
    return "";
  }
}

function _douyu_putEmojiTitle(map, title, url) {
  const cleanURL = _douyu_pickAbsoluteHttpURL(url);
  if (!cleanURL) return;
  let name = _douyu_str(title).trim();
  if (!name) return;
  // strip surrounding brackets once
  if (name.charAt(0) === "[" && name.charAt(name.length - 1) === "]") {
    name = name.slice(1, -1).trim();
  }
  if (!name) return;
  const key = "[" + name + "]";
  // Prefer first writer; do not overwrite existing system assets with weaker entries.
  if (!map[key]) map[key] = cleanURL;
}

function _douyu_seedSystemTitleAliases(map) {
  // dy108 -> also [108], [dy108], [emot:dy108]
  const keys = Object.keys(map);
  for (let i = 0; i < keys.length; i += 1) {
    const code = keys[i];
    if (!/^dy\d+$/i.test(code)) continue;
    const url = map[code];
    if (!_douyu_pickAbsoluteHttpURL(url)) continue;
    const digits = code.replace(/^dy/i, "");
    _douyu_putEmojiTitle(map, digits, url);
    _douyu_putEmojiTitle(map, code, url);
    _douyu_putEmojiTitle(map, "emot:" + code, url);
  }
  // Chinese names from built-in jn table: "[奋斗]" -> dy108 url
  const nameKeys = Object.keys(__douyu_emojiNameToCode || {});
  for (let j = 0; j < nameKeys.length; j += 1) {
    const title = nameKeys[j];
    const code = __douyu_emojiNameToCode[title];
    if (code && map[code]) _douyu_putEmojiTitle(map, title, map[code]);
  }
}

function _douyu_mergeWebEmotionPayload(map, payloadText) {
  let obj = null;
  try {
    obj = JSON.parse(_douyu_str(payloadText) || "null");
  } catch (e) {
    return 0;
  }
  if (!obj || typeof obj !== "object") return 0;
  const groups = obj.emotion;
  if (!Array.isArray(groups)) return 0;
  let count = 0;
  for (let i = 0; i < groups.length; i += 1) {
    const group = groups[i];
    if (!group || typeof group !== "object") continue;
    const em = group.em;
    if (!em || typeof em !== "object") continue;
    const names = Object.keys(em);
    for (let j = 0; j < names.length; j += 1) {
      const keyName = names[j];
      const meta = em[keyName];
      if (!meta || typeof meta !== "object") continue;
      if (Number(meta.is_deleted) === 1) continue;
      const url = meta.img_url || meta.imgUrl || meta.url || "";
      // Prefer simple_name for barrage title like [狗骨头]
      const simple = meta.simple_name || meta.simpleName || "";
      if (simple) {
        _douyu_putEmojiTitle(map, simple, url);
        count += 1;
      }
      if (keyName) {
        _douyu_putEmojiTitle(map, keyName, url);
        count += 1;
      }
    }
  }
  return count;
}

function _douyu_mergeDfansEmojisPayload(map, payloadText) {
  let obj = null;
  try {
    obj = JSON.parse(_douyu_str(payloadText) || "null");
  } catch (e) {
    return 0;
  }
  if (!obj || typeof obj !== "object") return 0;
  const data = obj.data;
  if (!data || typeof data !== "object") return 0;
  let count = 0;

  const emoList = Array.isArray(data.emoList) ? data.emoList : [];
  for (let i = 0; i < emoList.length; i += 1) {
    const item = emoList[i];
    if (!item || typeof item !== "object") continue;
    const title = item.text || item.eid || item.name || "";
    const url = item.pic || item.bigPic || item.url || "";
    _douyu_putEmojiTitle(map, title, url);
    if (title) count += 1;
  }

  const comm = Array.isArray(data.commEmoList) ? data.commEmoList : [];
  for (let j = 0; j < comm.length; j += 1) {
    const item = comm[j];
    if (!item || typeof item !== "object") continue;
    const title = item.text || item.name || item.eid || "";
    const url = item.pic || item.bigPic || item.url || "";
    _douyu_putEmojiTitle(map, title, url);
    if (title) count += 1;
  }

  const popular = data.popularEmojis && typeof data.popularEmojis === "object" ? data.popularEmojis : {};
  const popList = Array.isArray(popular.list) ? popular.list : [];
  for (let k = 0; k < popList.length; k += 1) {
    const item = popList[k];
    if (!item || typeof item !== "object") continue;
    const title = item.name || item.text || "";
    const url = item.webPic || item.appPic || item.pic || item.url || "";
    _douyu_putEmojiTitle(map, title, url);
    if (title) count += 1;
  }

  return count;
}

async function _douyu_fetchSystemDyMapFromAside(roomId) {
  const rid = _douyu_str(roomId).trim() || "9999";
  const pageURL = __douyu_emojiRoomPageBase + encodeURIComponent(rid);
  const html = await _douyu_httpGetText(pageURL);
  if (!html) return null;
  const declarationURL = _douyu_extractDeclarationURL(html);
  if (!declarationURL) return null;
  const declarationText = await _douyu_httpGetText(declarationURL);
  if (!declarationText) return null;
  const asideURL = _douyu_extractAsideBundleURL(declarationText);
  if (!asideURL) return null;
  const asideText = await _douyu_httpGetText(asideURL);
  if (!asideText) return null;
  const map = _douyu_extractAsideAssetMap(asideText);
  if (!map || Object.keys(map).length === 0) return null;
  return map;
}

async function _douyu_fetchEmojiMapFromWeb(roomId) {
  const rid = _douyu_str(roomId).trim() || "9999";
  // Start from built-in system dy assets.
  const map = _douyu_cloneEmojiMap(__douyu_emojiMapFallback);

  // 1) site-wide message/web emotion packs (simple_name like 狗骨头) — no login.
  try {
    const emotionText = await _douyu_httpGetText(__douyu_webEmotionURL, {
      Accept: "application/vnd.msg.douyu.com.v2+json",
      "dy-client": "web",
      Referer: "https://msg.douyu.com/web/index.html"
    });
    _douyu_mergeWebEmotionPayload(map, emotionText);
  } catch (e) {
  }

  // 2) room / popular / diamond emojis — no login.
  try {
    const dfansText = await _douyu_httpGetText(__douyu_dfansEmojisURL + encodeURIComponent(rid), {
      Accept: "application/json, text/plain, */*",
      Referer: "https://www.douyu.com/" + encodeURIComponent(rid),
      "X-Requested-With": "XMLHttpRequest"
    });
    _douyu_mergeDfansEmojisPayload(map, dfansText);
  } catch (e) {
  }

  // 3) optional: refresh system dy CDN hashes from live-next-player-aside.
  try {
    const systemMap = await _douyu_fetchSystemDyMapFromAside(rid);
    if (systemMap) {
      const codes = Object.keys(systemMap);
      for (let i = 0; i < codes.length; i += 1) {
        const code = codes[i];
        const url = _douyu_pickAbsoluteHttpURL(systemMap[code]);
        if (url) map[code] = url;
      }
    }
  } catch (e) {
  }

  _douyu_seedSystemTitleAliases(map);
  return map;
}

function _douyu_ensureEmojiMap(roomId) {
  if (__douyu_emojiMap && Object.keys(__douyu_emojiMap).length > 0) {
    return Promise.resolve(__douyu_emojiMap);
  }
  if (__douyu_emojiMapPromise) return __douyu_emojiMapPromise;

  __douyu_emojiMapPromise = _douyu_fetchEmojiMapFromWeb(roomId).then(function (map) {
    if (map && Object.keys(map).length > 0) {
      __douyu_emojiMap = map;
    } else {
      const fallback = _douyu_cloneEmojiMap(__douyu_emojiMapFallback);
      _douyu_seedSystemTitleAliases(fallback);
      __douyu_emojiMap = fallback;
    }
    return __douyu_emojiMap;
  }).catch(function () {
    const fallback = _douyu_cloneEmojiMap(__douyu_emojiMapFallback);
    _douyu_seedSystemTitleAliases(fallback);
    __douyu_emojiMap = fallback;
    return __douyu_emojiMap;
  });

  return __douyu_emojiMapPromise;
}

function _douyu_resolveEmotCode(token) {
  // Web appendFaceCode inserts "[" + title + "]".
  // System title is usually "108"/"001"; legacy/mobile may use "dy108" or "emot:dy108".
  const raw = _douyu_str(token).trim();
  if (!raw) return "";
  let body = raw;
  const emot = body.match(/^emot:(dy\d+)$/i);
  if (emot) body = emot[1];
  body = body.replace(/^emot:/i, "");
  if (/^dy\d+$/i.test(body)) return body.toLowerCase();
  if (/^\d+$/.test(body)) return "dy" + body;
  return "";
}

function _douyu_imageForPlainEmotContent(content, emojiMap) {
  // Whole-message image only.
  // Supports:
  // - system: [108] / [dy108] / [emot:dy108] / [奋斗]
  // - web packs / room packs: [狗骨头] / [梗已老实] via title map
  const text = _douyu_str(content).trim();
  if (!text) return null;
  const map = emojiMap && typeof emojiMap === "object" ? emojiMap : _douyu_activeEmojiMap();

  // Direct title hit (most common for Chinese faces).
  let url = _douyu_pickAbsoluteHttpURL(map && map[text]);
  if (url) return { url: url };

  let code = "";
  const bracket = text.match(/^\[([^\]]+)\]$/);
  if (bracket) {
    const inner = _douyu_str(bracket[1]).trim();
    // exact bracket key variants already tried via full text; try bare inner as title key
    url = _douyu_pickAbsoluteHttpURL(map && map["[" + inner + "]"]);
    if (url) return { url: url };
    code = _douyu_resolveEmotCode(inner);
    if (!code && __douyu_emojiNameToCode[text]) {
      code = __douyu_emojiNameToCode[text];
    } else if (!code && __douyu_emojiNameToCode["[" + inner + "]"]) {
      code = __douyu_emojiNameToCode["[" + inner + "]"];
    }
  } else {
    code = _douyu_resolveEmotCode(text);
  }
  if (!code) return null;

  url = _douyu_pickAbsoluteHttpURL(map && map[code]);
  if (!url && /^\d+$/.test(code.replace(/^dy/i, ""))) {
    const digits = code.replace(/^dy/i, "");
    let paddedDigits = digits;
    while (paddedDigits.length < 3) paddedDigits = "0" + paddedDigits;
    const padded = "dy" + paddedDigits;
    url = _douyu_pickAbsoluteHttpURL(map && map[padded]);
  }
  if (!url) return null;
  return { url: url };
}

function _douyu_lookupEmojiToken(token, emojiMap) {
  // token may be "[狗骨头]" / "[108]" / "108" / "emot:dy108"
  const raw = _douyu_str(token).trim();
  if (!raw) return null;
  const map = emojiMap && typeof emojiMap === "object" ? emojiMap : _douyu_activeEmojiMap();
  const bracketed = raw.charAt(0) === "[" && raw.charAt(raw.length - 1) === "]" ? raw : "[" + raw + "]";
  let url = _douyu_pickAbsoluteHttpURL(map && map[bracketed]);
  if (!url) url = _douyu_pickAbsoluteHttpURL(map && map[raw]);
  if (!url) {
    const image = _douyu_imageForPlainEmotContent(bracketed, map);
    if (image) url = image.url;
  }
  if (!url) return null;
  return { url: url, alt: bracketed };
}

function _douyu_mergeAdjacentTextSegments(segments) {
  const out = [];
  for (let i = 0; i < segments.length; i += 1) {
    const seg = segments[i];
    if (!seg || typeof seg !== "object") continue;
    if (seg.type === "text") {
      const t = _douyu_str(seg.text);
      if (!t) continue;
      const last = out.length ? out[out.length - 1] : null;
      if (last && last.type === "text") last.text = _douyu_str(last.text) + t;
      else out.push({ type: "text", text: t });
      continue;
    }
    if (seg.type === "image") {
      const url = _douyu_pickAbsoluteHttpURL(seg.url);
      if (!url) continue;
      const imageSeg = { type: "image", url: url };
      if (seg.alt) imageSeg.alt = _douyu_str(seg.alt);
      out.push(imageSeg);
    }
  }
  return out;
}

function _douyu_buildEmojiSegments(content, emojiMap) {
  const text = _douyu_str(content);
  if (!text) return [];
  const segments = [];
  const re = /\[([^\]]+)\]/g;
  let last = 0;
  let match = re.exec(text);
  while (match) {
    const full = match[0];
    const start = match.index;
    if (start > last) segments.push({ type: "text", text: text.slice(last, start) });
    const image = _douyu_lookupEmojiToken(full, emojiMap);
    if (image) segments.push({ type: "image", url: image.url, alt: image.alt || full });
    else segments.push({ type: "text", text: full });
    last = start + full.length;
    match = re.exec(text);
  }
  if (last < text.length) segments.push({ type: "text", text: text.slice(last) });
  return _douyu_mergeAdjacentTextSegments(segments);
}

function _douyu_makeChatMessage(nickname, text, color, emojiMap) {
  const content = _douyu_str(text);
  if (!content) return null;
  const message = {
    nickname: _douyu_str(nickname),
    text: content,
    color: _douyu_mapColor(color)
  };
  const segments = _douyu_buildEmojiSegments(content, emojiMap);
  let imageCount = 0;
  for (let i = 0; i < segments.length; i += 1) {
    if (segments[i].type === "image") imageCount += 1;
  }
  if (imageCount > 0) message.segments = segments;
  if (segments.length === 1 && segments[0].type === "image") {
    message.image = { url: segments[0].url };
    if (segments[0].alt) message.image.alt = segments[0].alt;
  }
  return message;
}

function _douyu_session(connectionId) {
  const key = _douyu_str(connectionId);
  const session = __douyu_danmakuSessions[key];
  if (!session) {
    _douyu_throw("INVALID_STATE", "danmaku session not found", { connectionId: key });
  }
  return session;
}

function _douyu_tryJoinWrites(session) {
  if (!session || !session.loggedIn || session.joined) return [];
  const gid = _douyu_str(session.gid || "").trim() || __douyu_defaultGid;
  session.joined = true;
  session.joinedGid = gid;
  return [_douyu_joinWrite(session.roomId, gid)];
}

const __douyuDanmakuDriver = {
  async getDanmakuPlan(roomId) {
    const rid = _douyu_str(roomId).trim();
    if (!rid) _douyu_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    const url = _douyu_pickProxyUrl(rid);
    return {
      args: {
        roomId: rid,
        url: url
      },
      headers: {
        "User-Agent": __douyu_connectionUserAgent,
        Origin: "https://www.douyu.com"
      },
      transport: {
        kind: "websocket",
        url: url,
        frameType: "binary"
      },
      runtime: {
        driver: "plugin_js_v1",
        protocolId: "douyu_ws_stt",
        protocolVersion: "1"
      }
    };
  },

  async createDanmakuSession(payload) {
    const connectionId = _douyu_str(payload && payload.connectionId);
    if (!connectionId) _douyu_throw("INVALID_ARGS", "connectionId is required", { field: "connectionId" });
    const args = payload && payload.args ? payload.args : {};
    const roomId = _douyu_str(args.roomId);
    if (!roomId) _douyu_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });

    __douyu_danmakuSessions[connectionId] = {
      connectionId: connectionId,
      roomId: roomId,
      url: _douyu_str(args.url || ""),
      loggedIn: false,
      joined: false,
      gid: "",
      joinedGid: "",
      lastHeartbeatAt: 0
    };

    // Optional HTTP discovery must not hold up login, frames or heartbeats.
    // The built-in map remains available until the background refresh completes.
    _douyu_ensureEmojiMap(roomId);

    return {
      ok: true,
      timer: {
        mode: "off"
      }
    };
  },

  async onDanmakuOpen(payload) {
    const session = _douyu_session(payload && payload.connectionId);
    session.loggedIn = false;
    session.joined = false;
    session.lastHeartbeatAt = Date.now();
    // Web: login first; joingroup after loginres / setmsggroup.
    return {
      writes: [_douyu_loginWrite(session.roomId)],
      timer: _douyu_timer()
    };
  },

  async onDanmakuFrame(payload) {
    const session = _douyu_session(payload && payload.connectionId);
    const packets = _douyu_decodePackets(
      _douyu_base64ToBytes(payload && payload.bytesBase64 ? payload.bytesBase64 : "")
    );
    const messages = [];
    const writes = [];

    for (let i = 0; i < packets.length; i += 1) {
      const packet = packets[i];
      const type = packet.type;

      if (type === "chatmsg") {
        // Official web client marks automated chat with robot=1.
        // Match only this field; nicknames, levels and repeated text are not bot signals.
        if (_douyu_pickField(packet.text, "robot") === "1") continue;
        const text = _douyu_pickField(packet.text, "txt");
        const message = _douyu_makeChatMessage(
          _douyu_pickField(packet.text, "nn"),
          text,
          _douyu_pickField(packet.text, "col"),
          _douyu_activeEmojiMap()
        );
        if (message) messages.push(message);
        continue;
      }

      if (type === "loginres") {
        session.loggedIn = true;
        // Prefer roomgroup from loginres when setmsggroup has not arrived yet.
        const roomGroup = _douyu_pickField(packet.text, "roomgroup");
        if (!session.gid && roomGroup && roomGroup !== "0") {
          session.gid = roomGroup;
        }
        writes.push.apply(writes, _douyu_tryJoinWrites(session));
        continue;
      }

      if (type === "setmsggroup") {
        const gid = _douyu_pickField(packet.text, "gid");
        if (gid) session.gid = gid;
        // If already joined with fallback, re-join once when real gid appears.
        if (session.joined && session.joinedGid !== session.gid && session.gid) {
          session.joined = false;
        }
        writes.push.apply(writes, _douyu_tryJoinWrites(session));
        continue;
      }

      if (type === "pingreq") {
        // The current web client answers pingreq/tick with a plain mrkl packet.
        // Echoing tick changes the STT payload and can make danmuproxy close the peer.
        _douyu_appendHeartbeat(session, writes);
        continue;
      }
    }

    // Some host builds do not reliably deliver the independent timer callback.
    // Piggyback a throttled heartbeat on inbound traffic so active rooms stay alive.
    _douyu_appendHeartbeatIfDue(session, writes);

    return {
      writes: writes,
      messages: messages
    };
  },

  async onDanmakuTick(payload) {
    const session = _douyu_session(payload && payload.connectionId);
    const writes = [];
    _douyu_appendHeartbeat(session, writes);
    return {
      writes: writes,
      timer: _douyu_timer()
    };
  },

  async destroyDanmakuSession(payload) {
    const connectionId = _douyu_str(payload && payload.connectionId);
    if (connectionId) delete __douyu_danmakuSessions[connectionId];
    return {
      ok: true
    };
  }
};

__douyuDanmakuDriver.__setEmojiMapForTest = function (map) {
  __douyu_emojiMap = map && typeof map === "object" ? _douyu_cloneEmojiMap(map) : _douyu_cloneEmojiMap(__douyu_emojiMapFallback);
  __douyu_emojiMapPromise = Promise.resolve(__douyu_emojiMap);
  return __douyu_emojiMap;
};

__douyuDanmakuDriver.__resetEmojiMapForTest = function () {
  __douyu_emojiMap = null;
  __douyu_emojiMapPromise = null;
};

__douyuDanmakuDriver.__imageForPlainEmotContentForTest = function (content, map) {
  return _douyu_imageForPlainEmotContent(content, map);
};

__douyuDanmakuDriver.__buildEmojiSegmentsForTest = function (content, map) {
  return _douyu_buildEmojiSegments(content, map);
};

__douyuDanmakuDriver.__makeChatMessageForTest = function (nickname, text, color, map) {
  return _douyu_makeChatMessage(nickname, text, color, map);
};

__douyuDanmakuDriver.__resolveEmotCodeForTest = function (token) {
  return _douyu_resolveEmotCode(token);
};

__douyuDanmakuDriver.__mergeWebEmotionPayloadForTest = function (map, payloadText) {
  const out = map && typeof map === "object" ? map : {};
  _douyu_mergeWebEmotionPayload(out, payloadText);
  return out;
};

__douyuDanmakuDriver.__mergeDfansEmojisPayloadForTest = function (map, payloadText) {
  const out = map && typeof map === "object" ? map : {};
  _douyu_mergeDfansEmojisPayload(out, payloadText);
  return out;
};

__douyuDanmakuDriver.__seedSystemTitleAliasesForTest = function (map) {
  const out = map && typeof map === "object" ? map : {};
  _douyu_seedSystemTitleAliases(out);
  return out;
};

__douyuDanmakuDriver.__extractAsideAssetMapForTest = function (jsText) {
  return _douyu_extractAsideAssetMap(jsText);
};

__douyuDanmakuDriver.__extractDeclarationURLForTest = function (html) {
  return _douyu_extractDeclarationURL(html);
};

__douyuDanmakuDriver.__extractAsideBundleURLForTest = function (text) {
  return _douyu_extractAsideBundleURL(text);
};

__douyuDanmakuDriver.__fallbackEmojiMapForTest = function () {
  return _douyu_cloneEmojiMap(__douyu_emojiMapFallback);
};

globalThis.__douyuDanmakuDriver = __douyuDanmakuDriver;
})();
